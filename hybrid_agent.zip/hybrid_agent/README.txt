The project was done in python (version 3.8.6). The libraries used that might need installation were:
Pygame
numpy
math
random
mateplotlib
datetime

To run the project, just run the command "python main_game.py". It will ask the number of cars in the simulation (500, for example). It will also ask about the flow. For this project, we used:
45: High flow
75: Average Flow
125: Low flow

At the end of the simulation, type 1 to plot the graphs. They will be saved on the directory "Results".